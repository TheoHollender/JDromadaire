package functions;

import java.util.ArrayList;

import main.EntryPoint;
import parser.nodes.FunctionNode;
import parser.nodes.NumberNode;
import variables.VariableContext;

public class RandintFunction extends FunctionNode{

	public RandintFunction(int col, int line) {
		super(col, line);
		// TODO Auto-generated constructor stub
	}
	public Object evaluate(VariableContext context, ArrayList<Object> args) {
		int debut = 0;
		int fin = 1;
		if(args.size()==1) {
			if (!(args.get(0) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as first argument, got "+args.get(0).getClass().toString());
	            return null;
			}
			if (!(((NumberNode)args.get(0)).getValue() instanceof Integer)) {
	            EntryPoint.raiseErr("Expected integer as first argument, got "+((NumberNode)args.get(0)).getValue() .getClass().toString());
	            return null;
			}
			if (((Integer)((NumberNode)args.get(0)).getValue())<=0) {
				EntryPoint.raiseErr("Excepted positive integer as first argument");
			}
			fin = (int) ((NumberNode)args.get(0)).getValue();
		}
		else if(args.size()==2) {
			if (!(args.get(0) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as first argument, got "+args.get(0).getClass().toString());
	            return null;
			}
			if (!(args.get(1) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as second argument, got "+args.get(1).getClass().toString());
	            return null;
			}
			if (!(((NumberNode)args.get(0)).getValue() instanceof Integer)) {
	            EntryPoint.raiseErr("Expected integer as first argument, got "+((NumberNode)args.get(0)).getValue() .getClass().toString());
	            return null;
			}
			if (!(((NumberNode)args.get(1)).getValue() instanceof Integer)) {
	            EntryPoint.raiseErr("Expected integer as second argument, got "+((NumberNode)args.get(0)).getValue() .getClass().toString());
	            return null;
			}
			if (((Integer)((NumberNode)args.get(0)).getValue())>=((Integer)((NumberNode)args.get(1)).getValue())) {
				EntryPoint.raiseErr("Excepted first argument smaller than second argument");
			}
			debut = (int) ((NumberNode)args.get(0)).getValue();
			fin = (int) ((NumberNode)args.get(1)).getValue();
		}
		else {
			EntryPoint.raiseErr("1 or 2 arguments expected, "+args.size()+" received");
			return null;
		}
		return new NumberNode((int) (Math.random()*(fin-debut+1)+debut),-2,-2);
	}

}
