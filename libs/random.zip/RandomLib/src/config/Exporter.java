package config;

import java.util.HashMap;

import functions.ChoiceFunction;
import functions.RandintFunction;
import functions.RandomFunction;
import libs.LibExporter;
import parser.Node;
import parser.nodes.StringNode;

public class Exporter implements LibExporter{

	@Override
	public HashMap<String, Node> exportClasses() {
		// TODO Auto-generated method stub
		HashMap<String,Node> hash = new HashMap();
		hash.put("version",new StringNode(-2,-2,"<module \"random\" from /libs/random.jar>\n0.0.1 (default, Avril 8 2021, 09:37) \n[Java 1.8]"));
		hash.put("random", new RandomFunction(-2,-2));
		hash.put("randint",new RandintFunction(-2,-2));
		hash.put("choice",new ChoiceFunction(-2,-2));
		return hash;
	}

}
