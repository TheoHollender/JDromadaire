package config;

import java.util.HashMap;

import functions.GetFunction;
import libs.LibExporter;
import parser.Node;
import parser.nodes.StringNode;

public class Exporter implements LibExporter{

	@Override
	public HashMap<String, Node> exportClasses() {
		// TODO Auto-generated method stub
		HashMap<String,Node> hash = new HashMap();
		hash.put("version",new StringNode(-2,-2,"<module \"requests\" from /libs/requests.jar>\n0.0.1 (default, Avril 8 2021, 09:37) \n[Java 1.8]"));
		hash.put("get",new GetFunction(-2,-2));
		return hash;
	}

}
