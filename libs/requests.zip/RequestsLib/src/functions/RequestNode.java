package functions;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;

import main.EntryPoint;
import parser.nodes.NumberNode;
import parser.nodes.StringNode;
import variables.ClassNode;
import variables.VariableContext;

public class RequestNode extends ClassNode {
	
	private int status;

	public RequestNode(int col, int line, int status, String text) {
		super(col, line);
		this.typeName = "request.Request";
		this.status=status;
		this.objects.put("status", new NumberNode(BigDecimal.valueOf(status),-1,-1));
		this.objects.put("text", new StringNode(-1,-1,text));
		isSetable = false;
	}

	public Object createInstance(VariableContext context, ArrayList<Object> args) {
		isRoot=false;
		if(!isRoot) {
			System.out.println("Can't create instance with sub child");
			return null;
		}
		return null;
	}
	
	public String toString() {
		return "<Response ["+this.status+"]>";
	}
	
}
