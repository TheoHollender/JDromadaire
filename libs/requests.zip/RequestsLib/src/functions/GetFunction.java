package functions;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import main.EntryPoint;
import parser.Node;
import parser.nodes.FunctionNode;
import parser.nodes.NumberNode;
import parser.nodes.StringNode;
import variables.VariableContext;

public class GetFunction extends FunctionNode {

	public GetFunction(int col, int line) {
		super(col, line);
	}
	public Object evaluate(VariableContext context, ArrayList<Object> args, HashMap<StringNode, Object> kwargs_entry) {
		if(args.size()!=1) {
			EntryPoint.raiseErr("Expected 1 argument, got "+args.size());
            return null;
		}
		if (!(args.get(0) instanceof StringNode)) {
            EntryPoint.raiseErr("Expected string as first argument, got "+args.get(0).getClass().toString());
            return null;
		}
		URL url;
		try {
			url = new URL((String) ((StringNode) args.get(0)).getValue());
		} catch (MalformedURLException e) {
			e.printStackTrace();
			EntryPoint.raiseErr("Expected valid url as first argument");
            return null;
		}
		HttpURLConnection con;
		try {
			con = (HttpURLConnection) url.openConnection();
		} catch (IOException e1) {
			EntryPoint.raiseErr("Error while openning connection");
            return null;
		}
		try {
			con.setRequestMethod("GET");
		} catch (ProtocolException e) {
			EntryPoint.raiseErr("Error while getting content");
            return null;
		}
		int status;
		try {
			status = con.getResponseCode();
		} catch (IOException e) {
			EntryPoint.raiseErr("Error while getting the status");
            return null;
		}
		BufferedReader in;
		String content = "";
		try {
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		} catch (IOException e1) {
			EntryPoint.raiseErr("Error while reading Input Stream");
            return null;
		}
        String l;
        try {
			while ((l=in.readLine())!=null) {
			    content+=l;
			}
		} catch (IOException e) {
			EntryPoint.raiseErr("Error while reading file");
            return null;
		}
		return new RequestNode(col,line,status,content);
	}
}