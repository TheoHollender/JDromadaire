package functions;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import main.EntryPoint;
import parser.nodes.FunctionNode;
import parser.nodes.NumberNode;
import variables.VariableContext;

public class RandintFunction extends FunctionNode{

	public RandintFunction(int col, int line) {
		super(col, line);
		// TODO Auto-generated constructor stub
	}
	public Object evaluate(VariableContext context, ArrayList<Object> args) {
		BigDecimal debut = BigDecimal.ZERO;
		BigDecimal fin = BigDecimal.ONE;
		if(args.size()==1) {
			if (!(args.get(0) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as first argument, got "+args.get(0).getClass().toString());
	            return null;
			}
			if (!(((NumberNode)args.get(0)).isInt())) {
	            EntryPoint.raiseErr("Expected integer as first argument, got float");
	            return null;
			}
			if (((Integer)((NumberNode)args.get(0)).getNumber().compareTo(BigDecimal.ZERO))<0) {
				EntryPoint.raiseErr("Excepted positive integer as first argument");
			}
			fin = ((NumberNode)args.get(0)).getNumber();
		}
		else if(args.size()==2) {
			if (!(args.get(0) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as first argument, got "+args.get(0).getClass().toString());
	            return null;
			}
			if (!(args.get(1) instanceof NumberNode)) {
	            EntryPoint.raiseErr("Expected number as second argument, got "+args.get(1).getClass().toString());
	            return null;
			}
			if (!(((NumberNode)args.get(0)).isInt())) {
	            EntryPoint.raiseErr("Expected integer as first argument, got float");
	            return null;
			}
			if (!(((NumberNode)args.get(1)).isInt())) {
	            EntryPoint.raiseErr("Expected integer as second argument, got float");
	            return null;
			}
			if ((((NumberNode)args.get(0)).getNumber()).compareTo(((NumberNode)args.get(1)).getNumber()) >= 0) {
				EntryPoint.raiseErr("Excepted first argument smaller than second argument");
			}
			debut = ((NumberNode)args.get(0)).getNumber();
			fin = ((NumberNode)args.get(1)).getNumber();
		}
		else {
			EntryPoint.raiseErr("1 or 2 arguments expected, "+args.size()+" received");
			return null;
		}
		BigDecimal v = BigDecimal.valueOf(Math.random()).multiply(fin.subtract(debut).add(BigDecimal.ONE)).add(debut).setScale(0, RoundingMode.FLOOR);
		return new NumberNode(v,-2,-2);
	}

}
