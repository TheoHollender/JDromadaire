package functions;

import java.util.ArrayList;

import main.EntryPoint;
import parser.nodes.FunctionNode;
import parser.nodes.NumberNode;
import variables.VariableContext;

public class NowFunction extends FunctionNode{

	public NowFunction(int col, int line) {
		super(col, line);
		// TODO Auto-generated constructor stub
	}
	public Object evaluate(VariableContext context, ArrayList<Object> args) {
		if(args.size()!=0) {
			EntryPoint.raiseErr("Expected 0 argument, got "+args.size());
            return null;
		}
		return new NumberNode((int) (System.currentTimeMillis()/1000),-2,-2);
	}

}
