package config;

import java.util.HashMap;

import functions.math.AbsFunction;
import functions.math.AcosFunction;
import functions.math.AcoshFunction;
import functions.math.AsinFunction;
import functions.math.AsinhFunction;
import functions.math.AtanFunction;
import functions.math.AtanhFunction;
import functions.math.CosFunction;
import functions.math.FacFunction;
import functions.math.LnFunction;
import functions.math.LogFunction;
import functions.math.RadiansFunction;
import functions.math.RootFunction;
import functions.math.SinFunction;
import functions.math.SinhFunction;
import functions.math.SqrtFunction;
import functions.math.TanFunction;
import functions.math.TanhFunction;
import functions.math.CoshFunction;
import functions.math.ExpFunction;
import libs.LibExporter;
import parser.Node;
import parser.nodes.NumberNode;
import parser.nodes.StringNode;

public class Exporter implements LibExporter{

	@Override
	public HashMap<String, Node> exportClasses() {
		// TODO Auto-generated method stub
		HashMap<String,Node> hash = new HashMap();
		hash.put("sqrt", new SqrtFunction(-2,-2));
		hash.put("abs", new AbsFunction(-2,-2));
		hash.put("pi", new NumberNode(Math.round(10000000000d*Math.toRadians(180))/10000000000d,-2,-2));
		hash.put("factorial", new FacFunction(-2,-2));
		hash.put("acos", new AcosFunction(-2,-2));
		hash.put("acosh", new AcoshFunction(-2,-2));
		hash.put("asin", new AsinFunction(-2,-2));
		hash.put("asinh", new AsinhFunction(-2,-2));
		hash.put("atan", new AtanFunction(-2,-2));
		hash.put("atanh", new AtanhFunction(-2,-2));
		hash.put("cos", new CosFunction(-2,-2));
		hash.put("cosh", new CoshFunction(-2,-2));
		hash.put("exp", new ExpFunction(-2,-2));
		hash.put("ln", new LnFunction(-2,-2));
		hash.put("log", new LogFunction(-2,-2));
		hash.put("radians", new RadiansFunction(-2,-2));
		hash.put("root", new RootFunction(-2,-2));
		hash.put("sin", new SinFunction(-2,-2));
		hash.put("sinh", new SinhFunction(-2,-2));
		hash.put("tan", new TanFunction(-2,-2));
		hash.put("tanh", new TanhFunction(-2,-2));
		hash.put("version", new StringNode(-2,-2,"<module \"math\" from /libs/math.jar>\n0.0.1 (default, Avril 7 2021, 09:37) \n[Java 1.8]"));
		return hash;
	}

}
