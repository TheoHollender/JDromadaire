package server;

import java.util.ArrayList;

import BaseSubsystems.NL_BaseSubsystem.NL_BaseSubsystem;
import main.EntryPoint;
import parser.nodes.BooleanNode;
import parser.nodes.FunctionNode;
import parser.nodes.NumberNode;
import variables.ClassNode;
import variables.VariableContext;

public class ServerNode extends ClassNode {
	
	private int id;
	protected ServerNode(ClassNode other, ArrayList<Object> args) {
		super(other, args);
		
		System.out.println("Serv args "+args);
		if (args.size() != 1) {
			EntryPoint.raiseErr("Expected 1 argument for server, got "+args.size());
			return;
		}
		
		if(args.get(0) instanceof NumberNode &&
				((NumberNode)args.get(0)).value instanceof Integer &&
				((Integer)((NumberNode)args.get(0)).value)>= 0 &&
				((Integer)((NumberNode)args.get(0)).value)<= 65535) {
			id = subsystem.createServer(((Integer)((NumberNode)args.get(0)).value));
		} else {
			EntryPoint.raiseErr("Expected a positive integer as server port, received "+args.get(0));
			return;
		}
	}
	
	public ServerNode(int col, int line) {
		super(col, line);
		
		this.objects.put("accept", new AcceptFunction(-1, -1));
	}
	
	public static boolean getThis(ArrayList<Object> args) {
		if (args.size() == 0) {
			EntryPoint.raiseErr("Expected at least 1 argument, got 0");
			return false;
		}
		if (!(args.get(0) instanceof ServerNode)) {
			EntryPoint.raiseErr("Expected Server Node as first argument, got "+args.get(0).getClass());
			return false;
		}
		return true;
	}
	
	public Object createInstance(VariableContext context, ArrayList<Object> args) {
		if(!isRoot) {
			System.out.println("Can't create instance with sub child");
			return null;
		}
		return new ServerNode(this, args);
	}
	
	public static class AcceptFunction extends FunctionNode {

		public AcceptFunction(int col, int line) {
			super(col, line);
		}
		
		public Object evaluate(VariableContext ctx, ArrayList<Object> args) {
			if (!getThis(args)) {
				return null;
			}
			
			ServerNode obj = (ServerNode) args.get(0);
			
			if (obj.subsystem.hasNewSocket()) {
				return new SocketNode(-1, -1, obj.subsystem.getNewSocket());
			}
			
			return new BooleanNode(-1, -1, false);
		}
		
	}

	public static NL_BaseSubsystem subsystem;

}
